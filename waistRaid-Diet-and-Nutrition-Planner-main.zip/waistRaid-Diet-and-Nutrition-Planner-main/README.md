# waistRaid-Diet-and-Nutrition-Planner
Diet and Nutrition Planner is a full-stack web app that generates personalized diet plans using user health metrics like BMI, activity level, and goals. It includes interactive recipes, optional AI-based suggestions, a fun UI, and secure authentication using React, Node.js, and MongoDB.
